import { LoadingAnimation } from './Loading.styles'

/* eslint-disable react/react-in-jsx-scope */
function Loading () {
  return (
        <LoadingAnimation>
            Loading.............
        </LoadingAnimation>
  )
}

export default Loading
