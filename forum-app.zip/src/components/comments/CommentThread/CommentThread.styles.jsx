import styled from 'styled-components'

export const CommentReply = styled.button`
border: 1px solid black;
  margin-left: 10px;
  padding: 10px;
  height: 100%;

  :hover {
    background-color: black;
    color: white;
    cursor: pointer
  }

`
