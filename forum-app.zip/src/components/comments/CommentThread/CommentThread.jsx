import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { asyncAddThreadComment } from '../../../store/comments/action'
import { ItemContainer } from '../../ThreadsList/ThreadItem/ThreadItem.styled'
import { CommentReply } from './CommentThread.styles'
import PropTypes from 'prop-types'
import { useNavigate } from 'react-router-dom'
/* eslint-disable react/react-in-jsx-scope */
function CommentThread ({ id }) {
  const [comment, setComment] = useState('')
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const onReplyThread = ({ id, comment }) => {
    dispatch(asyncAddThreadComment({ id, content: comment }))
    navigate(`/thread/${id}`)
  }

  const handleBodyChange = ({ target }) => {
    if (target.value.length <= 320) {
      setComment(target.value)
    }
  }

  return (
    <>
      <ItemContainer className="talk-input">
        <input type="text" placeholder="Body" value={comment} onChange={handleBodyChange}/>
        <p className="talk-input__char-left">
          <strong>{comment.length}</strong>
          /320
        </p>
        <CommentReply type='submit' onClick={() => onReplyThread({ id, comment })}>Balas</CommentReply>
      </ItemContainer>
    </>
  )
}

CommentThread.propTypes = {
  id: PropTypes.string.isRequired
}

export default CommentThread
