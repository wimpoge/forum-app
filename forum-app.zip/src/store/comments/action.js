import api from '../../utils/api'

const ActionType = {
  RECEIVE_THREAD_COMMENT: 'RECEIVE_THREAD_COMMENT',
  VOTE_UP_THREAD_COMMENT: 'VOTE_UP_THREAD_COMMENT'
}

function addThreadCommentActionCreator (commentId) {
  return {
    type: ActionType.RECEIVE_THREAD_COMMENT,
    payload: {
      commentId
    }
  }
}

// function voteUpThreadCommentActionCreator ({ userId, commentId }) {
//   return {
//     type: ActionType.VOTE_UP_THREAD_COMMENT,
//     payload: {
//       userId,
//       commentId
//     }
//   }
// }

function asyncAddThreadComment ({ content, id }) {
  return async (dispatch) => {
    try {
      const comment = await api.createComment({ content, id })
      dispatch(addThreadCommentActionCreator(comment))
    } catch (error) {
      alert(error.message)
    }
  }
}

// function asyncVoteUpThreadComment ({ threadId, commentId }) {
//   return async (dispatch, getState) => {
//     const { authUser } = getState()

//     dispatch(voteUpThreadCommentActionCreator({ userId: authUser.id, commentId }))

//     try {
//       await api.toggleUpVote({ threadId, commentId })
//     } catch (error) {
//       alert(error.message)
//     }
//   }
// }

export {
  ActionType,
  addThreadCommentActionCreator,
  asyncAddThreadComment
  // voteUpThreadCommentActionCreator,
  // asyncVoteUpThreadComment
}
