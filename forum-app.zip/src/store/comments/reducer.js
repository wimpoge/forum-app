import { ActionType } from './action'

function commentsReducer (threadComment = null, action = {}) {
  switch (action.type) {
    case ActionType.RECEIVE_THREAD_COMMENT:
      return {
        ...threadComment,
        comments: [action.payload.comment, ...threadComment.comments]
      }
    case ActionType.VOTE_UP_THREAD_COMMENT:
      return {
        ...threadComment,
        upVotesBy: threadComment.upVotesBy.includes(action.payload.userId)
          ? threadComment.upVotesBy.filter((id) => id !== action.payload.userId)
          : threadComment.upVotesBy.concat(action.payload.userId)
      }
    default:
      return threadComment
  }
}

export default commentsReducer
