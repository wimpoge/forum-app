import styled from 'styled-components'

export const LeaderboardsContainer = styled.div`
box-shadow: 5px 10px #888888;
justify-content: space-between;
display: flex;
margin: 50px;
padding: 10px;
`
